MDM Register - installable app (PWA)

Files: index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png
1. Upload ALL files to any free HTTPS host (Netlify Drop, GitHub Pages, Cloudflare Pages) in the same folder.
2. Open the site address in Chrome/Edge (PC or Android) -> Install app (address bar icon) / Add to Home screen.
3. After the first load it also opens offline.
Entries are saved in that browser on that device, under that site address. Always open the app from the same address.
